import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  private apiUrl = 'http://localhost:8080';  // Reemplaza con el puerto donde corren tus endpoints

  constructor(private http: HttpClient) {}

  // Obtener todas las listas
  getPlaylistFromSpotify(): Observable<any> {
    return this.http.get(`${this.apiUrl}/spotify-playlist`);
  }

  // Añadir una lista
  addPlaylist(playlist: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/lists`, playlist);
  }

  // Obtener una lista específica por nombre
  getPlaylistByName(name: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/lists/${name}`);
  }

  // Eliminar una lista
  deletePlaylist(name: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/lists/${name}`);
  }

  // Puedes agregar otros métodos si tienes autenticación o endpoints adicionales
}
