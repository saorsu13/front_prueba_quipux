import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  constructor(private router: Router) {}
  email: string = '';
  password: string = '';

  goToRegister() {
    this.router.navigate(['/register']);
  }

  goToPlaylist() {
    this.router.navigate(['/playlist']);
  }

  onLogin() {
    // Simular que la autenticación fue exitosa
    // Aquí iría la lógica de autenticación, como una llamada HTTP
    console.log('Inicio de sesión exitoso!');

    // Redirigir a la vista de Playlist después de la autenticación exitosa
    this.goToPlaylist();
  }

  onSubmit() {
    console.log('Email:', this.email);
    console.log('Password:', this.password);
  }

  handleEmailInput(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    this.email = inputElement.value;
  }

  handlePasswordInput(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    this.password = inputElement.value;
  }
}
