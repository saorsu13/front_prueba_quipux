import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css']
})
export class PlaylistComponent implements OnInit {
  playlistForm!: FormGroup;  // Formulario para la nueva playlist
  songForm!: FormGroup;      // Formulario para la nueva canción
  genres = ['Pop', 'Rock', 'Jazz', 'Clásica'];

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    // Inicializando los formularios
    this.playlistForm = this.fb.group({
      name: ['', Validators.required],
      description: ['']
    });

    this.songForm = this.fb.group({
      title: ['', Validators.required],
      artist: ['', Validators.required],
      album: [''],
      year: [''],
      genre: ['', Validators.required]
    });
  }

  addPlaylist() {
    console.log('Playlist añadida:', this.playlistForm.value);
  }

  addSong() {
    console.log('Canción añadida:', this.songForm.value);
  }
}
